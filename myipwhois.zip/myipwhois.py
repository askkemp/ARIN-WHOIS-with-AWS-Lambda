from __future__ import print_function
import json
from ipwhois import IPWhois

def lambda_handler(event, context):
    ipaddress = event['queryStringParameters']['ip']
    try:
        obj = IPWhois(ipaddress)
        results = json.dumps(obj.lookup_rdap(depth=20,retry_count=0,rate_limit_timeout=0))
        code = 200
    except Exception as e:
        myerror = { 'error': str(e).replace("'", "") }
        results = json.dumps(myerror)
        code = 599
        
    return {"statusCode": code, \
        "headers": {"Content-Type": "application/json"}, \
        "body": results}

